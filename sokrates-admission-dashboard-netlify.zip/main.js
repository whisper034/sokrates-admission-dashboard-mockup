(self["webpackChunksokrates_admission_dashboard_mockup"] = self["webpackChunksokrates_admission_dashboard_mockup"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nebular/theme */ 465);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 4364);



function AppComponent_ng_container_24_nb_icon_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "nb-icon", 53);
} }
function AppComponent_ng_container_24_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Overview");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "a", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Work Queue");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "a", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Quota Health");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "a", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Payments");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function AppComponent_ng_container_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "nb-icon", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, AppComponent_ng_container_24_nb_icon_5_Template, 1, 0, "nb-icon", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, AppComponent_ng_container_24_div_6_Template, 9, 0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const item_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", item_r14.active);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("icon", item_r14.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r14.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r14.hasChildren);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r14.label === "Dashboard");
} }
function AppComponent_nb_option_51_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nb-option", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const year_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", year_r17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](year_r17);
} }
function AppComponent_nb_option_53_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nb-option", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const campus_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", campus_r18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](campus_r18);
} }
function AppComponent_nb_option_55_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nb-option", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const level_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", level_r19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](level_r19);
} }
function AppComponent_nb_option_57_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nb-option", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const batch_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", batch_r20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](batch_r20);
} }
function AppComponent_div_59_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "nb-icon", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const kpi_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "metric metric-" + kpi_r21.status);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("icon", kpi_r21.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](kpi_r21.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](kpi_r21.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](kpi_r21.change);
} }
function AppComponent_div_68_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const step_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](step_r22.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", step_r22.value, " candidates");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", step_r22.conversion, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", step_r22.conversion, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](step_r22.aging);
} }
function AppComponent_tr_85_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r23.candidate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", item_r23.level, " - ", item_r23.campus, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r23.issue);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r23.priority.toLowerCase());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r23.age);
} }
function AppComponent_div_94_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "nb-progress-bar", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r24 = ctx.$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", item_r24.level, " - ", item_r24.campus, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r24.risk.toLowerCase().replace(" ", "-"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r24.risk);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r8.percent(item_r24.registered, item_r24.maxRegister));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate4"]("Registered ", item_r24.registered, "/", item_r24.maxRegister, " - Accepted ", item_r24.accepted, "/", item_r24.maxAccepted, "");
} }
function AppComponent_div_125_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "b", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r25 = ctx.$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r25.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", item_r25.candidate, " - ", item_r25.due, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r25.status.toLowerCase().replace(" ", "-"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r9.formatPaymentAmount(item_r25.amount));
} }
function AppComponent_div_133_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "nb-progress-bar", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r26 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r26.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", item_r26.value, " of ", item_r26.total, " candidates");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r10.percent(item_r26.value, item_r26.total), "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r10.percent(item_r26.value, item_r26.total));
} }
function AppComponent_div_142_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const school_r27 = ctx.$implicit;
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](school_r27.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", school_r27.value / ctx_r11.maxSourceValue() * 100, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](school_r27.value);
} }
function AppComponent_tr_159_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "small");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r28 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r28.level);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", item_r28.candidates, " candidates");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r28.batch);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r28.risk.toLowerCase().replace(" ", "-"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r28.risk);
} }
function AppComponent_div_167_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "nb-progress-bar", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r29 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r29.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", item_r29.value, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", item_r29.value);
} }
class AppComponent {
    constructor() {
        this.academicYears = ['2026/2027', '2025/2026'];
        this.campuses = ['All campuses', 'Simprug', 'Serpong', 'Bekasi'];
        this.schoolLevels = ['All levels', 'Playgroup', 'Kindergarten', 'Elementary', 'Junior High', 'Senior High'];
        this.batches = ['All batches', 'Batch 1 - Early Bird', 'Batch 2 - Regular', 'Batch 3 - Final'];
        this.selectedYear = '2026/2027';
        this.selectedCampus = 'All campuses';
        this.selectedLevel = 'All levels';
        this.selectedBatch = 'All batches';
        this.navItems = [
            { label: 'Dashboard', icon: 'grid-outline', active: true, hasChildren: true },
            { label: 'Agreement', icon: 'file-text-outline' },
            { label: 'Registration Form', icon: 'file-add-outline' },
            { label: 'PPDB Registration', icon: 'people-outline' },
            { label: 'Batch', icon: 'settings-2-outline' },
            { label: 'Test', icon: 'briefcase-outline', hasChildren: true },
            { label: 'Candidate', icon: 'people-outline' },
            { label: 'Candidate Transfer', icon: 'swap-outline', hasChildren: true },
            { label: 'Admission Fee Transaction', icon: 'percent-outline' },
            { label: 'Discount', icon: 'percent-outline', hasChildren: true },
            { label: 'Report', icon: 'file-text-outline', hasChildren: true },
        ];
        this.kpis = [];
        this.funnelSteps = [];
        this.workQueue = [];
        this.quotaItems = [];
        this.paymentQueue = [];
        this.sourceSchools = [];
        this.testReadiness = [];
        this.waitingList = [];
        this.dataQuality = [];
        this.paymentSummary = { expected: 0, received: 0, outstanding: 0 };
        this.paymentSplit = { paid: 0, partial: 0, unpaid: 0 };
        this.baseRecords = [
            this.record('2026/2027', 'Simprug', 'Kindergarten', 'K2', 'Batch 1 - Early Bird', 120, 103, 88, 78, 66, 54, 43, 3, 140, 90, 68, 18, 6, 165000000, 42000000, 480000000, 315000000, 48, 37, 78, 69, 59, 52, 18, 91, ['TK Notre Dame Puri', 'Little Stars Preschool', 'Saint Mary Primary']),
            this.record('2026/2027', 'Serpong', 'Elementary', 'Grade 1', 'Batch 2 - Regular', 214, 184, 158, 137, 112, 92, 76, 9, 230, 150, 124, 36, 14, 342000000, 98000000, 910000000, 568000000, 91, 67, 137, 109, 88, 76, 28, 84, ['Little Stars Preschool', 'Global Nusantara', 'Harapan Bangsa']),
            this.record('2026/2027', 'Bekasi', 'Elementary', 'Grade 4', 'Batch 2 - Regular', 156, 132, 116, 101, 84, 68, 51, 7, 180, 120, 88, 24, 8, 228000000, 59000000, 650000000, 422000000, 64, 42, 101, 83, 70, 62, 15, 88, ['Harapan Bangsa', 'Saint Mary Primary', 'Global Nusantara']),
            this.record('2026/2027', 'Simprug', 'Junior High', 'Grade 7', 'Batch 3 - Final', 96, 78, 61, 49, 38, 31, 24, 4, 160, 100, 52, 22, 7, 182000000, 50000000, 430000000, 248000000, 42, 30, 49, 41, 33, 29, 31, 76, ['Global Nusantara', 'Harapan Bangsa', 'BINUS School Simprug']),
            this.record('2026/2027', 'Serpong', 'Senior High', 'Grade 10', 'Batch 1 - Early Bird', 142, 122, 104, 91, 77, 64, 53, 5, 180, 120, 91, 19, 7, 205000000, 44000000, 610000000, 405000000, 58, 41, 91, 76, 64, 58, 16, 90, ['BINUS School Simprug', 'Global Nusantara', 'Harapan Bangsa']),
            this.record('2026/2027', 'Bekasi', 'Playgroup', 'Playgroup', 'Batch 1 - Early Bird', 72, 60, 48, 39, 31, 24, 20, 2, 110, 70, 39, 15, 5, 96000000, 21000000, 260000000, 164000000, 24, 18, 39, 31, 24, 20, 9, 82, ['Little Stars Preschool', 'TK Notre Dame Puri', 'Saint Mary Primary']),
            this.record('2025/2026', 'Simprug', 'Elementary', 'Grade 1', 'Batch 1 - Early Bird', 188, 164, 145, 124, 105, 91, 82, 6, 210, 140, 118, 20, 5, 198000000, 32000000, 780000000, 582000000, 54, 33, 124, 112, 96, 89, 12, 93, ['TK Notre Dame Puri', 'Little Stars Preschool', 'BINUS School Simprug']),
            this.record('2025/2026', 'Serpong', 'Junior High', 'Grade 7', 'Batch 2 - Regular', 133, 112, 94, 79, 65, 50, 43, 8, 170, 110, 80, 27, 11, 245000000, 69000000, 540000000, 295000000, 61, 44, 79, 65, 53, 47, 22, 79, ['Harapan Bangsa', 'Global Nusantara', 'Saint Mary Primary']),
            this.record('2025/2026', 'Bekasi', 'Senior High', 'Grade 10', 'Batch 3 - Final', 98, 80, 64, 55, 44, 34, 27, 5, 150, 95, 51, 21, 8, 176000000, 58000000, 410000000, 234000000, 43, 29, 55, 44, 37, 31, 19, 81, ['Global Nusantara', 'Harapan Bangsa', 'BINUS School Simprug']),
        ];
    }
    ngOnInit() {
        this.updateDashboard();
    }
    updateDashboard() {
        const records = this.filteredRecords();
        const totals = this.sumRecords(records);
        const previousTotal = Math.round(totals.registered * this.previousPeriodFactor());
        this.kpis = [
            {
                label: 'Active Candidates',
                value: this.formatNumber(totals.registered - totals.canceled),
                change: this.formatDelta(totals.registered, previousTotal, 'vs last period'),
                status: 'primary',
                icon: 'people-outline',
            },
            {
                label: 'Need Action Today',
                value: this.formatNumber(totals.needAction),
                change: `${this.formatNumber(totals.highPriority)} high priority`,
                status: totals.highPriority > 20 ? 'danger' : 'warning',
                icon: 'alert-triangle-outline',
            },
            {
                label: 'Admission Conversion',
                value: `${this.percent(totals.completed, totals.registered)}%`,
                change: `${this.formatSigned(this.conversionLift())} pts this month`,
                status: 'success',
                icon: 'trending-up-outline',
            },
            {
                label: 'Outstanding Payment',
                value: this.formatCurrency(totals.outstanding),
                change: `${this.formatCurrency(totals.overdue)} overdue`,
                status: totals.overdue > 75000000 ? 'warning' : 'success',
                icon: 'credit-card-outline',
            },
        ];
        this.funnelSteps = this.createFunnel(totals);
        this.quotaItems = this.createQuota(records);
        this.workQueue = this.createWorkQueue(records);
        this.paymentQueue = this.createPaymentQueue(records);
        this.sourceSchools = this.createSourceSchools(records);
        this.testReadiness = this.createReadiness(totals);
        this.waitingList = this.createWaitingList(records);
        this.dataQuality = this.createDataQuality(records);
        this.paymentSummary = {
            expected: totals.expectedPayment,
            received: totals.receivedPayment,
            outstanding: totals.outstanding,
        };
        this.paymentSplit = this.createPaymentSplit(totals);
    }
    percent(value, total) {
        if (!total) {
            return 0;
        }
        return Math.round((value / total) * 100);
    }
    formatNumber(value) {
        return new Intl.NumberFormat('en-US').format(value);
    }
    formatCurrency(value) {
        if (value >= 1000000000) {
            return `Rp ${(value / 1000000000).toFixed(2)}B`;
        }
        return `Rp ${Math.round(value / 1000000)}M`;
    }
    formatPaymentAmount(value) {
        return `Rp ${new Intl.NumberFormat('id-ID').format(value)}`;
    }
    maxSourceValue() {
        return Math.max(...this.sourceSchools.map(item => item.value), 1);
    }
    filteredRecords() {
        return this.baseRecords.filter(record => {
            const yearMatches = record.year === this.selectedYear;
            const campusMatches = this.selectedCampus === 'All campuses' || record.campus === this.selectedCampus;
            const levelMatches = this.selectedLevel === 'All levels' || record.levelGroup === this.selectedLevel;
            const batchMatches = this.selectedBatch === 'All batches' || record.batch === this.selectedBatch;
            return yearMatches && campusMatches && levelMatches && batchMatches;
        });
    }
    sumRecords(records) {
        return records.reduce((total, record) => (Object.assign(Object.assign({}, total), { registered: total.registered + record.registered, formComplete: total.formComplete + record.formComplete, registrationPaid: total.registrationPaid + record.registrationPaid, testScheduled: total.testScheduled + record.testScheduled, passedOrWaitingList: total.passedOrWaitingList + record.passedOrWaitingList, finalPayment: total.finalPayment + record.finalPayment, completed: total.completed + record.completed, canceled: total.canceled + record.canceled, maxRegister: total.maxRegister + record.maxRegister, maxAccepted: total.maxAccepted + record.maxAccepted, accepted: total.accepted + record.accepted, needAction: total.needAction + record.needAction, highPriority: total.highPriority + record.highPriority, outstanding: total.outstanding + record.outstanding, overdue: total.overdue + record.overdue, expectedPayment: total.expectedPayment + record.expectedPayment, receivedPayment: total.receivedPayment + record.receivedPayment, partialPayment: total.partialPayment + record.partialPayment, unpaidPayment: total.unpaidPayment + record.unpaidPayment, scheduled: total.scheduled + record.scheduled, present: total.present + record.present, scoresComplete: total.scoresComplete + record.scoresComplete, resultsPublished: total.resultsPublished + record.resultsPublished, waitingList: total.waitingList + record.waitingList, dataQuality: total.dataQuality + record.dataQuality })), this.emptyRecord());
    }
    createFunnel(totals) {
        const steps = [
            ['Registered', totals.registered, 0.8],
            ['Form Complete', totals.formComplete, 1.4],
            ['Reg. Payment Paid', totals.registrationPaid, 2.1],
            ['Test Scheduled', totals.testScheduled, 3.7],
            ['Passed / WL', totals.passedOrWaitingList, 4.9],
            ['Final Payment', totals.finalPayment, 5.6],
            ['Completed', totals.completed, 6.2],
        ];
        return steps.map(([label, value, baseAging]) => ({
            label,
            value,
            conversion: this.percent(value, totals.registered),
            aging: `${(baseAging * this.agingFactor()).toFixed(1)}d`,
        }));
    }
    createQuota(records) {
        return records.map(record => {
            const usage = this.percent(record.accepted, record.maxAccepted);
            let risk = 'Healthy';
            if (usage >= 100) {
                risk = 'Full';
            }
            else if (usage >= 85) {
                risk = 'Near Full';
            }
            else if (this.percent(record.registered, record.maxRegister) < 65) {
                risk = 'Low Demand';
            }
            return {
                level: record.level,
                campus: record.campus,
                registered: record.registered,
                maxRegister: record.maxRegister,
                accepted: record.accepted,
                maxAccepted: record.maxAccepted,
                risk,
            };
        }).slice(0, 5);
    }
    createWorkQueue(records) {
        const issueMap = ['Final payment proof waiting verification', 'Registration form missing parent phone', 'Discount approval pending', 'Test result not published', 'Email verification resend needed'];
        return records.reduce((queueItems, record, index) => {
            const count = Math.max(1, Math.min(2, Math.ceil(record.needAction / 25)));
            const recordItems = Array.from({ length: count }).map((_, queueIndex) => ({
                candidate: this.candidateName(index + queueIndex),
                level: record.level,
                campus: record.campus,
                issue: issueMap[(index + queueIndex) % issueMap.length],
                age: `${Math.max(1, Math.round(record.needAction / 8) + queueIndex)}d ${queueIndex ? '4h' : '8h'}`,
                priority: record.highPriority > 10 ? 'High' : record.needAction > 18 ? 'Medium' : 'Low',
            }));
            return queueItems.concat(recordItems);
        }, []).slice(0, 5);
    }
    createPaymentQueue(records) {
        const statuses = ['Verify', 'Overdue', 'Due Soon', 'Partial'];
        return records.map((record, index) => ({
            candidate: this.candidateName(index + 5),
            type: index % 2 === 0 ? 'Final Payment' : 'Registration Fee',
            amount: Math.max(750000, Math.round(record.outstanding / Math.max(record.needAction, 1))),
            due: `${25 + (index % 6)} Aug`,
            status: statuses[index % statuses.length],
        })).slice(0, 4);
    }
    createSourceSchools(records) {
        const sourceMap = new Map();
        records.forEach(record => {
            record.sourceSchools.forEach((school, index) => {
                sourceMap.set(school.name, (sourceMap.get(school.name) || 0) + Math.round(record.registered / (index + 3)));
            });
        });
        return Array.from(sourceMap.entries())
            .map(([name, value]) => ({ name, value }))
            .sort((left, right) => right.value - left.value)
            .slice(0, 5);
    }
    createReadiness(totals) {
        return [
            { label: 'Scheduled', value: totals.scheduled, total: totals.registrationPaid },
            { label: 'Present', value: totals.present, total: totals.scheduled },
            { label: 'Scores Complete', value: totals.scoresComplete, total: totals.present },
            { label: 'Results Published', value: totals.resultsPublished, total: totals.scoresComplete },
        ];
    }
    createWaitingList(records) {
        return records
            .filter(record => record.waitingList > 0)
            .map(record => {
            const risk = record.waitingList > 25 ? 'Near Full' : record.waitingList < 12 ? 'Healthy' : 'Low Demand';
            return {
                level: record.level,
                batch: record.batch.replace('Batch ', 'Target Batch '),
                campus: record.campus,
                candidates: record.waitingList,
                risk,
            };
        })
            .slice(0, 4);
    }
    createDataQuality(records) {
        const average = records.length ? Math.round(records.reduce((sum, record) => sum + record.dataQuality, 0) / records.length) : 0;
        return [
            { label: 'Complete parent contact', value: Math.min(99, average + 3) },
            { label: 'Required files uploaded', value: Math.max(0, average - 4) },
            { label: 'Verified candidate email', value: Math.max(0, average - 10) },
            { label: 'No duplicate indicators', value: Math.min(99, average + 7) },
        ];
    }
    createPaymentSplit(totals) {
        const expected = totals.expectedPayment || 1;
        const paid = this.percent(totals.receivedPayment, expected);
        const partial = this.percent(totals.partialPayment, expected);
        return {
            paid: Math.min(paid, 100),
            partial: Math.min(partial, Math.max(0, 100 - paid)),
            unpaid: Math.max(0, 100 - paid - partial),
        };
    }
    record(year, campus, levelGroup, level, batch, registered, formComplete, registrationPaid, testScheduled, passedOrWaitingList, finalPayment, completed, canceled, maxRegister, maxAccepted, accepted, needAction, highPriority, outstanding, overdue, expectedPayment, receivedPayment, partialPayment, unpaidPayment, scheduled, present, scoresComplete, resultsPublished, waitingList, dataQuality, sources) {
        return {
            year,
            campus,
            levelGroup,
            level,
            batch,
            registered,
            formComplete,
            registrationPaid,
            testScheduled,
            passedOrWaitingList,
            finalPayment,
            completed,
            canceled,
            maxRegister,
            maxAccepted,
            accepted,
            needAction,
            highPriority,
            outstanding,
            overdue,
            expectedPayment,
            receivedPayment,
            partialPayment,
            unpaidPayment,
            scheduled,
            present,
            scoresComplete,
            resultsPublished,
            waitingList,
            dataQuality,
            sourceSchools: sources.map((name, index) => ({ name, value: Math.round(registered / (index + 3)) })),
        };
    }
    emptyRecord() {
        return this.record('', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, []);
    }
    candidateName(index) {
        const names = ['Alya Putri', 'Jason Tan', 'Nabila Sari', 'Rafi Wijaya', 'Michael Hartono', 'Keisha Amanda', 'Darren Lim', 'Zahra Putri', 'Bryan Pratama'];
        return names[index % names.length];
    }
    previousPeriodFactor() {
        return this.selectedYear === '2026/2027' ? 0.85 : 1.08;
    }
    conversionLift() {
        const base = this.selectedYear === '2026/2027' ? 4.2 : -1.6;
        const campusAdjustment = this.selectedCampus === 'All campuses' ? 0 : 0.7;
        const batchAdjustment = this.selectedBatch === 'Batch 3 - Final' ? -1.3 : 0;
        return Number((base + campusAdjustment + batchAdjustment).toFixed(1));
    }
    agingFactor() {
        return this.selectedBatch === 'Batch 3 - Final' ? 1.25 : this.selectedCampus === 'All campuses' ? 1 : 0.9;
    }
    formatDelta(current, previous, suffix) {
        if (!previous) {
            return `0% ${suffix}`;
        }
        const delta = Math.round(((current - previous) / previous) * 100);
        return `${this.formatSigned(delta)}% ${suffix}`;
    }
    formatSigned(value) {
        return value > 0 ? `+${value}` : `${value}`;
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 168, vars: 27, consts: [["fixed", "", 1, "top-shell"], [1, "top-left"], ["nbButton", "", "ghost", "", "status", "info", "size", "small", 1, "icon-button"], ["icon", "menu-2-outline"], [1, "school-logo"], [1, "top-right"], [1, "offline-dot"], ["nbButton", "", "outline", "", "status", "info", "size", "small", 1, "round-button"], ["icon", "bell-outline"], ["icon", "globe-2-outline"], ["nbButton", "", "outline", "", "status", "info", "size", "small", 1, "tenant-button"], [1, "avatar"], [1, "app-shell"], [1, "side-nav"], [4, "ngFor", "ngForOf"], [1, "powered"], [1, "content"], [1, "page-bar"], [1, "breadcrumb"], ["icon", "home-outline"], ["icon", "chevron-right-outline"], ["icon", "grid-outline"], [1, "panel", "controls-panel"], [1, "dashboard-heading"], ["nbButton", "", "status", "success", "size", "small"], ["icon", "download-outline"], [1, "filter-row"], ["placeholder", "Academic year", 3, "selected", "selectedChange"], [3, "value", 4, "ngFor", "ngForOf"], ["placeholder", "School location", 3, "selected", "selectedChange"], ["placeholder", "School level", 3, "selected", "selectedChange"], ["placeholder", "Batch", 3, "selected", "selectedChange"], [1, "metric-strip"], [3, "ngClass", 4, "ngFor", "ngForOf"], [1, "insight-grid"], [1, "panel", "span-7"], [1, "funnel"], ["class", "funnel-row", 4, "ngFor", "ngForOf"], [1, "panel", "span-5"], [1, "compact-table"], [1, "panel", "span-4"], [1, "quota-list"], ["class", "quota-item", 4, "ngFor", "ngForOf"], [1, "money-stack"], [1, "payment-split"], [1, "queue-list"], [1, "readiness-list"], ["class", "readiness-item", 4, "ngFor", "ngForOf"], [1, "source-list"], [1, "quality-list"], [3, "icon"], ["icon", "chevron-left-outline", "class", "chevron", 4, "ngIf"], ["class", "nav-group dashboard-subnav", 4, "ngIf"], ["icon", "chevron-left-outline", 1, "chevron"], [1, "nav-group", "dashboard-subnav"], [1, "sub-link", "active-sub"], [1, "sub-link"], [3, "value"], [3, "ngClass"], [1, "funnel-row"], [1, "funnel-label"], [1, "funnel-track"], [1, "funnel-fill"], [1, "aging"], [1, "status-pill", 3, "ngClass"], [1, "quota-item"], [1, "quota-top"], ["size", "tiny", 3, "value"], [1, "readiness-item"], ["size", "tiny", "status", "success", 3, "value"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "nb-layout");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "nb-layout-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "nb-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "ND");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "Notre Dame");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Offline");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "nb-icon", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "nb-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, "Notre Dame");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "ND");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "nb-layout-column");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "aside", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "nav");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, AppComponent_ng_container_24_Template, 7, 6, "ng-container", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Powered by ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Sokrates");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "main", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](30, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "nb-icon", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](33, "nb-icon", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](34, "nb-icon", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "Admission Dashboard");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "time");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Friday, August 28, 2026");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "section", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "header", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "Admission Dashboard");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, "Operational health, capacity, payment risk, and demand insight for PPDB teams");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](46, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](47, "nb-icon", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](48, " Export Summary ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "nb-select", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("selectedChange", function AppComponent_Template_nb_select_selectedChange_50_listener($event) { return ctx.selectedYear = $event; })("selectedChange", function AppComponent_Template_nb_select_selectedChange_50_listener() { return ctx.updateDashboard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](51, AppComponent_nb_option_51_Template, 2, 2, "nb-option", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "nb-select", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("selectedChange", function AppComponent_Template_nb_select_selectedChange_52_listener($event) { return ctx.selectedCampus = $event; })("selectedChange", function AppComponent_Template_nb_select_selectedChange_52_listener() { return ctx.updateDashboard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](53, AppComponent_nb_option_53_Template, 2, 2, "nb-option", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "nb-select", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("selectedChange", function AppComponent_Template_nb_select_selectedChange_54_listener($event) { return ctx.selectedLevel = $event; })("selectedChange", function AppComponent_Template_nb_select_selectedChange_54_listener() { return ctx.updateDashboard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](55, AppComponent_nb_option_55_Template, 2, 2, "nb-option", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "nb-select", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("selectedChange", function AppComponent_Template_nb_select_selectedChange_56_listener($event) { return ctx.selectedBatch = $event; })("selectedChange", function AppComponent_Template_nb_select_selectedChange_56_listener() { return ctx.updateDashboard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](57, AppComponent_nb_option_57_Template, 2, 2, "nb-option", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](59, AppComponent_div_59_Template, 8, 5, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "section", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](61, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](64, "Admission Funnel Overview");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "Candidate progression, conversion, and average aging by status");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](68, AppComponent_div_68_Template, 12, 6, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](72, "Admin Work Queue");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74, "Prioritized actions from payment, forms, discounts, tests, and NIS generation");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "table", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](79, "Queue");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, "Issue");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "SLA");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](85, AppComponent_tr_85_Template, 11, 6, "tr", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "section", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](87, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](90, "Quota and Capacity Health");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](91, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](92, "Registered candidates versus accepted seat limits by year level");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](93, "div", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](94, AppComponent_div_94_Template, 9, 9, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](98, "Payment and Collection");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](100, "Expected cash-in, received payment, outstanding amount, and verification risk");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](101, "div", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](104, "Expected");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](105, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](106);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](107, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](108, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](109, "Received");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](111);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](112, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](114, "Outstanding");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](115, "strong");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](116);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](117, "div", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Paid");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](121, "Partial");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123, "Unpaid");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "div", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](125, AppComponent_div_125_Template, 8, 5, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](127, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](129, "Test Readiness");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](131, "Schedule coverage, attendance, score completion, and result publication");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "div", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](133, AppComponent_div_133_Template, 9, 5, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](134, "section", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](138, "Candidate Source and Demand");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](140, "Top origin schools and acquisition signal");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](141, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](142, AppComponent_div_142_Template, 7, 4, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](144, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](145, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](146, "Waiting List and Re-register");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](148, "Candidate movement risk across target batches");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](149, "table", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](150, "thead");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](153, "Level");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](155, "Target Batch");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](157, "Risk");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](159, AppComponent_tr_159_Template, 11, 5, "tr", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](161, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](163, "Registration Form Data Quality");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](164, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](165, "Completeness and reliability indicators for candidate records");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](166, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](167, AppComponent_div_167_Template, 6, 3, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.navItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("selected", ctx.selectedYear);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.academicYears);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("selected", ctx.selectedCampus);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.campuses);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("selected", ctx.selectedLevel);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.schoolLevels);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("selected", ctx.selectedBatch);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.batches);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.kpis);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.funnelSteps);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.workQueue);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.quotaItems);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.formatCurrency(ctx.paymentSummary.expected));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.formatCurrency(ctx.paymentSummary.received));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.formatCurrency(ctx.paymentSummary.outstanding));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx.paymentSplit.paid, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx.paymentSplit.partial, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx.paymentSplit.unpaid, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.paymentQueue);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.testReadiness);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.sourceSchools);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.waitingList);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.dataQuality);
    } }, directives: [_nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbLayoutComponent, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbLayoutHeaderComponent, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbButtonComponent, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbIconComponent, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbLayoutColumnComponent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbSelectComponent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbOptionComponent, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgClass, _nebular_theme__WEBPACK_IMPORTED_MODULE_1__.NbProgressBarComponent], styles: ["[_nghost-%COMP%] {\n  --primary: #0b95d8;\n  --sidebar: #0b5f88;\n  --sidebar-dark: #09577d;\n  --content-bg: #eef4fb;\n  --table-blue: #3f64cc;\n  --border: #c8d6ec;\n  display: block;\n  font-family: \"Open Sans\", Arial, sans-serif;\n  min-height: 100vh;\n}\n\n*[_ngcontent-%COMP%] {\n  font-family: \"Open Sans\", Arial, sans-serif;\n}\n\n  nb-layout .layout {\n  background: var(--content-bg);\n}\n\n  nb-layout-header.top-shell {\n  background: #f7fcff;\n  border-bottom: 1px solid #d9e5f3;\n  box-shadow: 0 2px 7px rgba(22, 42, 74, 0.08);\n  height: 4.5rem;\n  padding: 0 1.5rem;\n}\n\n  nb-layout-column {\n  padding: 0 !important;\n}\n\n.top-left[_ngcontent-%COMP%], .top-right[_ngcontent-%COMP%], .breadcrumb[_ngcontent-%COMP%], .metric[_ngcontent-%COMP%], .funnel-row[_ngcontent-%COMP%], .readiness-item[_ngcontent-%COMP%], .queue-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%], .quota-top[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n}\n\n.top-left[_ngcontent-%COMP%] {\n  color: #0a4970;\n  grid-gap: 1rem;\n  gap: 1rem;\n  font-size: 1rem;\n  font-weight: 700;\n}\n\n.icon-button[_ngcontent-%COMP%] {\n  color: var(--primary) !important;\n}\n\n.school-logo[_ngcontent-%COMP%] {\n  align-items: center;\n  background: #ffffff;\n  border: 1px solid #d8e6f5;\n  border-radius: 0.35rem;\n  box-shadow: 0 2px 8px rgba(33, 65, 105, 0.12);\n  color: #1c3870;\n  display: flex;\n  font-family: Georgia, serif;\n  font-size: 0.82rem;\n  font-weight: 800;\n  height: 2.55rem;\n  justify-content: center;\n  width: 2.55rem;\n}\n\n.top-right[_ngcontent-%COMP%] {\n  grid-gap: 0.75rem;\n  gap: 0.75rem;\n  justify-content: flex-end;\n  margin-left: auto;\n}\n\n.offline-dot[_ngcontent-%COMP%] {\n  color: #ff3d71;\n  font-size: 0.72rem;\n  font-weight: 800;\n  text-transform: uppercase;\n}\n\n.offline-dot[_ngcontent-%COMP%]::before {\n  background: #ff3d71;\n  border-radius: 50%;\n  box-shadow: 0 0 0 3px rgba(255, 61, 113, 0.15);\n  content: \"\";\n  display: inline-block;\n  height: 0.45rem;\n  margin-right: 0.35rem;\n  vertical-align: 0.02rem;\n  width: 0.45rem;\n}\n\n.round-button[_ngcontent-%COMP%] {\n  border-radius: 999px !important;\n  height: 2.45rem;\n  padding: 0 !important;\n  width: 2.45rem;\n}\n\n.round-button[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  margin: 0;\n}\n\n.tenant-button[_ngcontent-%COMP%] {\n  border-radius: 999px !important;\n  font-weight: 700;\n}\n\n.avatar[_ngcontent-%COMP%] {\n  align-items: center;\n  background: #eef3fb;\n  border: 1px solid #d4e0ef;\n  border-radius: 50%;\n  color: #4b5568;\n  display: flex;\n  font-size: 0.82rem;\n  font-weight: 700;\n  height: 2.35rem;\n  justify-content: center;\n  width: 2.35rem;\n}\n\n.app-shell[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 17rem minmax(0, 1fr);\n  min-height: calc(100vh - 4.5rem);\n}\n\n.side-nav[_ngcontent-%COMP%] {\n  background: linear-gradient(180deg, var(--sidebar), var(--sidebar-dark));\n  color: #d9f1ff;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  min-height: calc(100vh - 4.5rem);\n  padding: 0.85rem 1rem 0;\n}\n\n.side-nav[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.25rem;\n  gap: 0.25rem;\n}\n\n.side-nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  align-items: center;\n  border-radius: 0.75rem;\n  color: #cbe8f8;\n  display: flex;\n  font-size: 0.84rem;\n  font-weight: 700;\n  grid-gap: 0.8rem;\n  gap: 0.8rem;\n  min-height: 3rem;\n  padding: 0 1rem;\n  text-decoration: none;\n}\n\n.side-nav[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background: rgba(27, 142, 195, 0.65);\n  color: #ffffff;\n}\n\n.side-nav[_ngcontent-%COMP%]   .active-sub[_ngcontent-%COMP%] {\n  color: #ffffff;\n  font-weight: 800;\n}\n\n.side-nav[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  color: inherit;\n  font-size: 1.05rem;\n}\n\n.chevron[_ngcontent-%COMP%] {\n  margin-left: auto;\n}\n\n.nav-group[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.35rem;\n  gap: 0.35rem;\n  margin-top: 0.4rem;\n  padding-left: 1.3rem;\n}\n\n.side-nav[_ngcontent-%COMP%]   .sub-link[_ngcontent-%COMP%] {\n  font-size: 0.76rem;\n  min-height: 2rem;\n  padding: 0 0.9rem;\n}\n\n.powered[_ngcontent-%COMP%] {\n  background: #f8fbff;\n  border-top: 1px solid #d8e5f2;\n  color: #2e3a59;\n  font-size: 0.78rem;\n  margin: 1rem -1rem 0;\n  padding: 0.85rem 1rem;\n}\n\n.powered[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--primary);\n}\n\n.content[_ngcontent-%COMP%] {\n  padding: 2.25rem 1rem 2rem 2rem;\n}\n\n.page-bar[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n  margin: 0 0 1rem;\n}\n\n.breadcrumb[_ngcontent-%COMP%] {\n  color: #172033;\n  grid-gap: 0.55rem;\n  gap: 0.55rem;\n  font-size: 0.98rem;\n}\n\n.breadcrumb[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%]:first-child {\n  color: var(--primary);\n}\n\n.page-bar[_ngcontent-%COMP%]   time[_ngcontent-%COMP%] {\n  color: #2e3a59;\n  font-size: 0.82rem;\n}\n\n.panel[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid var(--border);\n  border-radius: 0.85rem;\n  padding: 1rem;\n}\n\n.controls-panel[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n}\n\n.dashboard-heading[_ngcontent-%COMP%] {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 1rem;\n}\n\nh1[_ngcontent-%COMP%] {\n  color: #172033;\n  font-size: 1.05rem;\n  font-weight: 800;\n  margin: 0;\n}\n\n.filter-row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.85rem;\n  gap: 0.85rem;\n  grid-template-columns: 1fr 1.1fr 1fr 1.2fr;\n  margin-bottom: 1.1rem;\n}\n\n.metric-strip[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.75rem;\n  gap: 0.75rem;\n  grid-template-columns: repeat(4, minmax(0, 1fr));\n}\n\n.metric[_ngcontent-%COMP%] {\n  background: #f8fbff;\n  border: 1px solid #e0e9f6;\n  border-radius: 0.35rem;\n  grid-gap: 0.65rem;\n  gap: 0.65rem;\n  min-height: 4.75rem;\n  padding: 0.7rem 0.85rem;\n}\n\n.metric[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  color: var(--primary);\n  font-size: 1.25rem;\n}\n\n.metric[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #6e7890;\n  display: block;\n  font-size: 0.67rem;\n  font-weight: 800;\n  text-transform: uppercase;\n}\n\n.metric[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 1.2rem;\n  margin-top: 0.15rem;\n}\n\n.metric[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: #8f9bb3;\n  display: block;\n  font-size: 0.66rem;\n  margin-top: 0.1rem;\n}\n\n.metric-danger[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  color: #ff3d71;\n}\n\n.metric-warning[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  color: #ffaa00;\n}\n\n.metric-success[_ngcontent-%COMP%]   nb-icon[_ngcontent-%COMP%] {\n  color: #00a974;\n}\n\n.insight-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 1rem;\n  gap: 1rem;\n  grid-template-columns: repeat(12, minmax(0, 1fr));\n  margin-bottom: 1rem;\n}\n\n.span-7[_ngcontent-%COMP%] {\n  grid-column: span 7;\n}\n\n.span-5[_ngcontent-%COMP%] {\n  grid-column: span 5;\n}\n\n.span-4[_ngcontent-%COMP%] {\n  grid-column: span 4;\n}\n\nheader[_ngcontent-%COMP%] {\n  margin-bottom: 0.85rem;\n}\n\nh2[_ngcontent-%COMP%], p[_ngcontent-%COMP%] {\n  margin: 0;\n}\n\nh2[_ngcontent-%COMP%] {\n  color: #172033;\n  font-size: 0.92rem;\n  font-weight: 800;\n}\n\np[_ngcontent-%COMP%], small[_ngcontent-%COMP%] {\n  color: #6e7890;\n}\n\nheader[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 0.72rem;\n  margin-top: 0.15rem;\n}\n\n.funnel[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.55rem;\n  gap: 0.55rem;\n}\n\n.funnel-row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.8rem;\n  gap: 0.8rem;\n  grid-template-columns: 10rem minmax(0, 1fr) 3rem;\n}\n\n.funnel-label[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 0.78rem;\n}\n\n.funnel-label[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 0.68rem;\n}\n\n.funnel-track[_ngcontent-%COMP%] {\n  background: #edf2fb;\n  border-radius: 0.2rem;\n  height: 1.25rem;\n  overflow: hidden;\n  position: relative;\n}\n\n.funnel-fill[_ngcontent-%COMP%] {\n  background: var(--primary);\n  height: 100%;\n}\n\n.funnel-track[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #172033;\n  font-size: 0.68rem;\n  font-weight: 800;\n  left: 0.45rem;\n  line-height: 1.25rem;\n  position: absolute;\n  top: 0;\n}\n\n.aging[_ngcontent-%COMP%] {\n  color: #6e7890;\n  font-size: 0.72rem;\n  text-align: right;\n}\n\n.compact-table[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%] {\n  border-collapse: collapse;\n  width: 100%;\n}\n\n.compact-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  border: 1px solid #d9e1ee;\n  font-size: 0.72rem;\n  line-height: 1.35;\n  padding: 0.48rem 0.42rem;\n  text-align: left;\n  vertical-align: top;\n}\n\n.compact-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  background: var(--table-blue);\n  color: #ffffff;\n  font-size: 0.78rem;\n  font-weight: 800;\n  text-align: center;\n}\n\n.compact-table[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], .compact-table[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 0.72rem;\n}\n\n.compact-table[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 0.68rem;\n}\n\n.status-pill[_ngcontent-%COMP%], .quota-top[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  border-radius: 999px;\n  display: inline-block;\n  font-size: 0.64rem;\n  font-weight: 800;\n  padding: 0.18rem 0.45rem;\n  white-space: nowrap;\n}\n\n.high[_ngcontent-%COMP%], .full[_ngcontent-%COMP%] {\n  background: #ffe7ef;\n  color: #d11b54;\n}\n\n.medium[_ngcontent-%COMP%], .near-full[_ngcontent-%COMP%] {\n  background: #fff2cf;\n  color: #8f5d00;\n}\n\n.low[_ngcontent-%COMP%], .healthy[_ngcontent-%COMP%] {\n  background: #def9ef;\n  color: #007452;\n}\n\n.low-demand[_ngcontent-%COMP%] {\n  background: #e8f2ff;\n  color: #136ab5;\n}\n\n.quota-list[_ngcontent-%COMP%], .money-stack[_ngcontent-%COMP%], .source-list[_ngcontent-%COMP%], .readiness-list[_ngcontent-%COMP%], .quality-list[_ngcontent-%COMP%], .queue-list[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.7rem;\n  gap: 0.7rem;\n}\n\n.quota-item[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.38rem;\n  gap: 0.38rem;\n}\n\n.quota-top[_ngcontent-%COMP%] {\n  justify-content: space-between;\n}\n\n.quota-top[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  font-size: 0.76rem;\n}\n\n.quota-item[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  font-size: 0.68rem;\n}\n\n.money-stack[_ngcontent-%COMP%] {\n  grid-template-columns: repeat(3, 1fr);\n}\n\n.money-stack[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  background: #f8fbff;\n  border: 1px solid #e0e9f6;\n  border-radius: 0.3rem;\n  padding: 0.75rem;\n}\n\n.money-stack[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #6e7890;\n  display: block;\n  font-size: 0.68rem;\n  font-weight: 800;\n  text-transform: uppercase;\n}\n\n.money-stack[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 1rem;\n  margin-top: 0.25rem;\n}\n\n.payment-split[_ngcontent-%COMP%] {\n  border-radius: 0.2rem;\n  display: flex;\n  height: 1.8rem;\n  margin: 0.85rem 0;\n  overflow: hidden;\n}\n\n.payment-split[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  align-items: center;\n  color: #ffffff;\n  display: flex;\n  font-size: 0.68rem;\n  font-weight: 800;\n  justify-content: center;\n}\n\n.payment-split[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:nth-child(1) {\n  background: #00d68f;\n}\n\n.payment-split[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:nth-child(2) {\n  background: #ffaa00;\n}\n\n.payment-split[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]:nth-child(3) {\n  background: #ff3d71;\n}\n\n.queue-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #edf2fb;\n  grid-gap: 0.7rem;\n  gap: 0.7rem;\n  justify-content: space-between;\n  padding-bottom: 0.5rem;\n}\n\n.queue-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:last-child {\n  border-bottom: 0;\n  padding-bottom: 0;\n}\n\n.queue-list[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 0.72rem;\n}\n\n.queue-list[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 0.68rem;\n  margin-top: 0.1rem;\n}\n\n.queue-list[_ngcontent-%COMP%]   b[_ngcontent-%COMP%] {\n  font-size: 0.7rem;\n  white-space: nowrap;\n}\n\n.overdue[_ngcontent-%COMP%] {\n  color: #d11b54;\n}\n\n.due-soon[_ngcontent-%COMP%], .partial[_ngcontent-%COMP%] {\n  color: #8f5d00;\n}\n\n.verify[_ngcontent-%COMP%] {\n  color: #007452;\n}\n\n.readiness-item[_ngcontent-%COMP%], .quality-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  display: grid;\n  grid-gap: 0.35rem;\n  gap: 0.35rem;\n}\n\n.readiness-item[_ngcontent-%COMP%] {\n  grid-template-columns: 1fr 2.5rem;\n}\n\n.readiness-item[_ngcontent-%COMP%]   nb-progress-bar[_ngcontent-%COMP%], .quality-list[_ngcontent-%COMP%]   nb-progress-bar[_ngcontent-%COMP%] {\n  grid-column: 1/-1;\n}\n\n.readiness-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%], .quality-list[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #172033;\n  display: block;\n  font-size: 0.76rem;\n  font-weight: 800;\n}\n\n.readiness-item[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 0.68rem;\n}\n\n.readiness-item[_ngcontent-%COMP%]    > span[_ngcontent-%COMP%], .quality-list[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--primary);\n  font-size: 0.78rem;\n  font-weight: 800;\n  text-align: right;\n}\n\n.quality-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  grid-template-columns: 1fr 2.5rem;\n}\n\n.source-list[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%] {\n  align-items: center;\n  display: grid;\n  grid-gap: 0.65rem;\n  gap: 0.65rem;\n  grid-template-columns: minmax(7rem, 10rem) 1fr 2rem;\n}\n\n.source-list[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: #2e3a59;\n  font-size: 0.72rem;\n}\n\n.source-list[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  background: #edf2fb;\n  border-radius: 0.2rem;\n  height: 0.55rem;\n  overflow: hidden;\n}\n\n.source-list[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  background: var(--primary);\n  display: block;\n  height: 100%;\n}\n\n.source-list[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #172033;\n  font-size: 0.72rem;\n  text-align: right;\n}\n\n@media (max-width: 1180px) {\n  .app-shell[_ngcontent-%COMP%] {\n    grid-template-columns: 4.5rem minmax(0, 1fr);\n  }\n\n  .side-nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   span[_ngcontent-%COMP%], .nav-group[_ngcontent-%COMP%], .powered[_ngcontent-%COMP%] {\n    display: none;\n  }\n\n  .side-nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    justify-content: center;\n    padding: 0;\n  }\n\n  .filter-row[_ngcontent-%COMP%], .metric-strip[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(2, minmax(0, 1fr));\n  }\n\n  .span-7[_ngcontent-%COMP%], .span-5[_ngcontent-%COMP%], .span-4[_ngcontent-%COMP%] {\n    grid-column: span 12;\n  }\n}\n\n@media (max-width: 760px) {\n  .top-right[_ngcontent-%COMP%] {\n    display: none;\n  }\n\n  .app-shell[_ngcontent-%COMP%] {\n    display: block;\n  }\n\n  .side-nav[_ngcontent-%COMP%] {\n    display: none;\n  }\n\n  .content[_ngcontent-%COMP%] {\n    padding: 1rem;\n  }\n\n  .page-bar[_ngcontent-%COMP%], .dashboard-heading[_ngcontent-%COMP%] {\n    align-items: flex-start;\n    flex-direction: column;\n  }\n\n  .filter-row[_ngcontent-%COMP%], .metric-strip[_ngcontent-%COMP%], .money-stack[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n\n  .funnel-row[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n\n  .aging[_ngcontent-%COMP%] {\n    text-align: left;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSwyQ0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSwyQ0FBQTtBQUNGOztBQUVBO0VBQ0UsNkJBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsZ0NBQUE7RUFDQSw0Q0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTs7Ozs7Ozs7RUFRRSxtQkFBQTtFQUNBLGFBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQUEsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0NBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsNkNBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGlCQUFBO0VBQUEsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLHVCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UsK0JBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxTQUFBO0FBQ0Y7O0FBRUE7RUFDRSwrQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSwyQ0FBQTtFQUNBLGdDQUFBO0FBQ0Y7O0FBRUE7RUFDRSx3RUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtFQUNBLGdDQUFBO0VBQ0EsdUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUFBLFlBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUFBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtBQUNGOztBQUVBO0VBQ0Usb0NBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUFBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsK0JBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtFQUFBLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSwrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQUEsWUFBQTtFQUNBLDBDQUFBO0VBQ0EscUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUFBLFlBQUE7RUFDQSxnREFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7RUFBQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFBeUIsY0FBQTtBQUV6Qjs7QUFEQTtFQUEwQixjQUFBO0FBSzFCOztBQUpBO0VBQTBCLGNBQUE7QUFRMUI7O0FBTkE7RUFDRSxhQUFBO0VBQ0EsY0FBQTtFQUFBLFNBQUE7RUFDQSxpREFBQTtFQUNBLG1CQUFBO0FBU0Y7O0FBTkE7RUFBVSxtQkFBQTtBQVVWOztBQVRBO0VBQVUsbUJBQUE7QUFhVjs7QUFaQTtFQUFVLG1CQUFBO0FBZ0JWOztBQWRBO0VBQ0Usc0JBQUE7QUFpQkY7O0FBZEE7O0VBRUUsU0FBQTtBQWlCRjs7QUFkQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBaUJGOztBQWRBOztFQUVFLGNBQUE7QUFpQkY7O0FBZEE7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FBaUJGOztBQWRBO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQUEsWUFBQTtBQWlCRjs7QUFkQTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtFQUFBLFdBQUE7RUFDQSxnREFBQTtBQWlCRjs7QUFkQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFpQkY7O0FBZEE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUFpQkY7O0FBZEE7RUFDRSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFpQkY7O0FBZEE7RUFDRSwwQkFBQTtFQUNBLFlBQUE7QUFpQkY7O0FBZEE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtBQWlCRjs7QUFkQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBaUJGOztBQWRBOztFQUVFLHlCQUFBO0VBQ0EsV0FBQTtBQWlCRjs7QUFkQTs7OztFQUlFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQWlCRjs7QUFkQTs7RUFFRSw2QkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFpQkY7O0FBZEE7O0VBRUUsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQWlCRjs7QUFkQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQWlCRjs7QUFkQTs7RUFFRSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7QUFpQkY7O0FBZEE7O0VBRUUsbUJBQUE7RUFDQSxjQUFBO0FBaUJGOztBQWRBOztFQUVFLG1CQUFBO0VBQ0EsY0FBQTtBQWlCRjs7QUFkQTs7RUFFRSxtQkFBQTtFQUNBLGNBQUE7QUFpQkY7O0FBZEE7RUFDRSxtQkFBQTtFQUNBLGNBQUE7QUFpQkY7O0FBZEE7Ozs7OztFQU1FLGFBQUE7RUFDQSxnQkFBQTtFQUFBLFdBQUE7QUFpQkY7O0FBZEE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFBQSxZQUFBO0FBaUJGOztBQWRBO0VBQ0UsOEJBQUE7QUFpQkY7O0FBZEE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUFpQkY7O0FBZEE7RUFDRSxrQkFBQTtBQWlCRjs7QUFkQTtFQUNFLHFDQUFBO0FBaUJGOztBQWRBO0VBQ0UsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7QUFpQkY7O0FBZEE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQWlCRjs7QUFkQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FBaUJGOztBQWRBO0VBQ0UscUJBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFpQkY7O0FBZEE7RUFDRSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBaUJGOztBQWRBO0VBQW1DLG1CQUFBO0FBa0JuQzs7QUFqQkE7RUFBbUMsbUJBQUE7QUFxQm5DOztBQXBCQTtFQUFtQyxtQkFBQTtBQXdCbkM7O0FBdEJBO0VBQ0UsZ0NBQUE7RUFDQSxnQkFBQTtFQUFBLFdBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0FBeUJGOztBQXRCQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7QUF5QkY7O0FBdEJBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQXlCRjs7QUF0QkE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQXlCRjs7QUF0QkE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBeUJGOztBQXRCQTtFQUNFLGNBQUE7QUF5QkY7O0FBdEJBOztFQUVFLGNBQUE7QUF5QkY7O0FBdEJBO0VBQ0UsY0FBQTtBQXlCRjs7QUF0QkE7O0VBRUUsYUFBQTtFQUNBLGlCQUFBO0VBQUEsWUFBQTtBQXlCRjs7QUF0QkE7RUFDRSxpQ0FBQTtBQXlCRjs7QUF0QkE7O0VBRUUsaUJBQUE7QUF5QkY7O0FBdEJBOztFQUVFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQXlCRjs7QUF0QkE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUF5QkY7O0FBdEJBOztFQUVFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBeUJGOztBQXRCQTtFQUNFLGlDQUFBO0FBeUJGOztBQXRCQTtFQUNFLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQUEsWUFBQTtFQUNBLG1EQUFBO0FBeUJGOztBQXRCQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQXlCRjs7QUF0QkE7RUFDRSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBeUJGOztBQXRCQTtFQUNFLDBCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUF5QkY7O0FBdEJBO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUF5QkY7O0FBdEJBO0VBQ0U7SUFDRSw0Q0FBQTtFQXlCRjs7RUF0QkE7OztJQUdFLGFBQUE7RUF5QkY7O0VBdEJBO0lBQ0UsdUJBQUE7SUFDQSxVQUFBO0VBeUJGOztFQXRCQTs7SUFFRSxnREFBQTtFQXlCRjs7RUF0QkE7OztJQUdFLG9CQUFBO0VBeUJGO0FBQ0Y7O0FBdEJBO0VBQ0U7SUFDRSxhQUFBO0VBd0JGOztFQXJCQTtJQUNFLGNBQUE7RUF3QkY7O0VBckJBO0lBQ0UsYUFBQTtFQXdCRjs7RUFyQkE7SUFDRSxhQUFBO0VBd0JGOztFQXJCQTs7SUFFRSx1QkFBQTtJQUNBLHNCQUFBO0VBd0JGOztFQXJCQTs7O0lBR0UsMEJBQUE7RUF3QkY7O0VBckJBO0lBQ0UsMEJBQUE7RUF3QkY7O0VBckJBO0lBQ0UsZ0JBQUE7RUF3QkY7QUFDRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIC0tcHJpbWFyeTogIzBiOTVkODtcbiAgLS1zaWRlYmFyOiAjMGI1Zjg4O1xuICAtLXNpZGViYXItZGFyazogIzA5NTc3ZDtcbiAgLS1jb250ZW50LWJnOiAjZWVmNGZiO1xuICAtLXRhYmxlLWJsdWU6ICMzZjY0Y2M7XG4gIC0tYm9yZGVyOiAjYzhkNmVjO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnLCBBcmlhbCwgc2Fucy1zZXJpZjtcbiAgbWluLWhlaWdodDogMTAwdmg7XG59XG5cbioge1xuICBmb250LWZhbWlseTogJ09wZW4gU2FucycsIEFyaWFsLCBzYW5zLXNlcmlmO1xufVxuXG46Om5nLWRlZXAgbmItbGF5b3V0IC5sYXlvdXQge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1jb250ZW50LWJnKTtcbn1cblxuOjpuZy1kZWVwIG5iLWxheW91dC1oZWFkZXIudG9wLXNoZWxsIHtcbiAgYmFja2dyb3VuZDogI2Y3ZmNmZjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkOWU1ZjM7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDdweCByZ2JhKDIyLCA0MiwgNzQsIDAuMDgpO1xuICBoZWlnaHQ6IDQuNXJlbTtcbiAgcGFkZGluZzogMCAxLjVyZW07XG59XG5cbjo6bmctZGVlcCBuYi1sYXlvdXQtY29sdW1uIHtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xufVxuXG4udG9wLWxlZnQsXG4udG9wLXJpZ2h0LFxuLmJyZWFkY3J1bWIsXG4ubWV0cmljLFxuLmZ1bm5lbC1yb3csXG4ucmVhZGluZXNzLWl0ZW0sXG4ucXVldWUtbGlzdCA+IGRpdixcbi5xdW90YS10b3Age1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4udG9wLWxlZnQge1xuICBjb2xvcjogIzBhNDk3MDtcbiAgZ2FwOiAxcmVtO1xuICBmb250LXNpemU6IDFyZW07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5pY29uLWJ1dHRvbiB7XG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5KSAhaW1wb3J0YW50O1xufVxuXG4uc2Nob29sLWxvZ28ge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDhlNmY1O1xuICBib3JkZXItcmFkaXVzOiAwLjM1cmVtO1xuICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgzMywgNjUsIDEwNSwgMC4xMik7XG4gIGNvbG9yOiAjMWMzODcwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LWZhbWlseTogR2VvcmdpYSwgc2VyaWY7XG4gIGZvbnQtc2l6ZTogMC44MnJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgaGVpZ2h0OiAyLjU1cmVtO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgd2lkdGg6IDIuNTVyZW07XG59XG5cbi50b3AtcmlnaHQge1xuICBnYXA6IDAuNzVyZW07XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xufVxuXG4ub2ZmbGluZS1kb3Qge1xuICBjb2xvcjogI2ZmM2Q3MTtcbiAgZm9udC1zaXplOiAwLjcycmVtO1xuICBmb250LXdlaWdodDogODAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4ub2ZmbGluZS1kb3Q6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQ6ICNmZjNkNzE7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYm94LXNoYWRvdzogMCAwIDAgM3B4IHJnYmEoMjU1LCA2MSwgMTEzLCAwLjE1KTtcbiAgY29udGVudDogJyc7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgaGVpZ2h0OiAwLjQ1cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDAuMzVyZW07XG4gIHZlcnRpY2FsLWFsaWduOiAwLjAycmVtO1xuICB3aWR0aDogMC40NXJlbTtcbn1cblxuLnJvdW5kLWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDk5OXB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMi40NXJlbTtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICB3aWR0aDogMi40NXJlbTtcbn1cblxuLnJvdW5kLWJ1dHRvbiBuYi1pY29uIHtcbiAgbWFyZ2luOiAwO1xufVxuXG4udGVuYW50LWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDk5OXB4ICFpbXBvcnRhbnQ7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5cbi5hdmF0YXIge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjZWVmM2ZiO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDRlMGVmO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGNvbG9yOiAjNGI1NTY4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDAuODJyZW07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGhlaWdodDogMi4zNXJlbTtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHdpZHRoOiAyLjM1cmVtO1xufVxuXG4uYXBwLXNoZWxsIHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxN3JlbSBtaW5tYXgoMCwgMWZyKTtcbiAgbWluLWhlaWdodDogY2FsYygxMDB2aCAtIDQuNXJlbSk7XG59XG5cbi5zaWRlLW5hdiB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsIHZhcigtLXNpZGViYXIpLCB2YXIoLS1zaWRlYmFyLWRhcmspKTtcbiAgY29sb3I6ICNkOWYxZmY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgbWluLWhlaWdodDogY2FsYygxMDB2aCAtIDQuNXJlbSk7XG4gIHBhZGRpbmc6IDAuODVyZW0gMXJlbSAwO1xufVxuXG4uc2lkZS1uYXYgbmF2IHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAwLjI1cmVtO1xufVxuXG4uc2lkZS1uYXYgYSB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDAuNzVyZW07XG4gIGNvbG9yOiAjY2JlOGY4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDAuODRyZW07XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGdhcDogMC44cmVtO1xuICBtaW4taGVpZ2h0OiAzcmVtO1xuICBwYWRkaW5nOiAwIDFyZW07XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuLnNpZGUtbmF2IGEuYWN0aXZlIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyNywgMTQyLCAxOTUsIDAuNjUpO1xuICBjb2xvcjogI2ZmZmZmZjtcbn1cblxuLnNpZGUtbmF2IC5hY3RpdmUtc3ViIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG59XG5cbi5zaWRlLW5hdiBuYi1pY29uIHtcbiAgY29sb3I6IGluaGVyaXQ7XG4gIGZvbnQtc2l6ZTogMS4wNXJlbTtcbn1cblxuLmNoZXZyb24ge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbn1cblxuLm5hdi1ncm91cCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMC4zNXJlbTtcbiAgbWFyZ2luLXRvcDogMC40cmVtO1xuICBwYWRkaW5nLWxlZnQ6IDEuM3JlbTtcbn1cblxuLnNpZGUtbmF2IC5zdWItbGluayB7XG4gIGZvbnQtc2l6ZTogMC43NnJlbTtcbiAgbWluLWhlaWdodDogMnJlbTtcbiAgcGFkZGluZzogMCAwLjlyZW07XG59XG5cbi5wb3dlcmVkIHtcbiAgYmFja2dyb3VuZDogI2Y4ZmJmZjtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNkOGU1ZjI7XG4gIGNvbG9yOiAjMmUzYTU5O1xuICBmb250LXNpemU6IDAuNzhyZW07XG4gIG1hcmdpbjogMXJlbSAtMXJlbSAwO1xuICBwYWRkaW5nOiAwLjg1cmVtIDFyZW07XG59XG5cbi5wb3dlcmVkIHN0cm9uZyB7XG4gIGNvbG9yOiB2YXIoLS1wcmltYXJ5KTtcbn1cblxuLmNvbnRlbnQge1xuICBwYWRkaW5nOiAyLjI1cmVtIDFyZW0gMnJlbSAycmVtO1xufVxuXG4ucGFnZS1iYXIge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIG1hcmdpbjogMCAwIDFyZW07XG59XG5cbi5icmVhZGNydW1iIHtcbiAgY29sb3I6ICMxNzIwMzM7XG4gIGdhcDogMC41NXJlbTtcbiAgZm9udC1zaXplOiAwLjk4cmVtO1xufVxuXG4uYnJlYWRjcnVtYiBuYi1pY29uOmZpcnN0LWNoaWxkIHtcbiAgY29sb3I6IHZhcigtLXByaW1hcnkpO1xufVxuXG4ucGFnZS1iYXIgdGltZSB7XG4gIGNvbG9yOiAjMmUzYTU5O1xuICBmb250LXNpemU6IDAuODJyZW07XG59XG5cbi5wYW5lbCB7XG4gIGJhY2tncm91bmQ6ICNmZmZmZmY7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWJvcmRlcik7XG4gIGJvcmRlci1yYWRpdXM6IDAuODVyZW07XG4gIHBhZGRpbmc6IDFyZW07XG59XG5cbi5jb250cm9scy1wYW5lbCB7XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG5cbi5kYXNoYm9hcmQtaGVhZGluZyB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cblxuaDEge1xuICBjb2xvcjogIzE3MjAzMztcbiAgZm9udC1zaXplOiAxLjA1cmVtO1xuICBmb250LXdlaWdodDogODAwO1xuICBtYXJnaW46IDA7XG59XG5cbi5maWx0ZXItcm93IHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAwLjg1cmVtO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxLjFmciAxZnIgMS4yZnI7XG4gIG1hcmdpbi1ib3R0b206IDEuMXJlbTtcbn1cblxuLm1ldHJpYy1zdHJpcCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMC43NXJlbTtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoNCwgbWlubWF4KDAsIDFmcikpO1xufVxuXG4ubWV0cmljIHtcbiAgYmFja2dyb3VuZDogI2Y4ZmJmZjtcbiAgYm9yZGVyOiAxcHggc29saWQgI2UwZTlmNjtcbiAgYm9yZGVyLXJhZGl1czogMC4zNXJlbTtcbiAgZ2FwOiAwLjY1cmVtO1xuICBtaW4taGVpZ2h0OiA0Ljc1cmVtO1xuICBwYWRkaW5nOiAwLjdyZW0gMC44NXJlbTtcbn1cblxuLm1ldHJpYyBuYi1pY29uIHtcbiAgY29sb3I6IHZhcigtLXByaW1hcnkpO1xuICBmb250LXNpemU6IDEuMjVyZW07XG59XG5cbi5tZXRyaWMgc3BhbiB7XG4gIGNvbG9yOiAjNmU3ODkwO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAwLjY3cmVtO1xuICBmb250LXdlaWdodDogODAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4ubWV0cmljIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTcyMDMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAxLjJyZW07XG4gIG1hcmdpbi10b3A6IDAuMTVyZW07XG59XG5cbi5tZXRyaWMgc21hbGwge1xuICBjb2xvcjogIzhmOWJiMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC42NnJlbTtcbiAgbWFyZ2luLXRvcDogMC4xcmVtO1xufVxuXG4ubWV0cmljLWRhbmdlciBuYi1pY29uIHsgY29sb3I6ICNmZjNkNzE7IH1cbi5tZXRyaWMtd2FybmluZyBuYi1pY29uIHsgY29sb3I6ICNmZmFhMDA7IH1cbi5tZXRyaWMtc3VjY2VzcyBuYi1pY29uIHsgY29sb3I6ICMwMGE5NzQ7IH1cblxuLmluc2lnaHQtZ3JpZCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMXJlbTtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMTIsIG1pbm1heCgwLCAxZnIpKTtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cblxuLnNwYW4tNyB7IGdyaWQtY29sdW1uOiBzcGFuIDc7IH1cbi5zcGFuLTUgeyBncmlkLWNvbHVtbjogc3BhbiA1OyB9XG4uc3Bhbi00IHsgZ3JpZC1jb2x1bW46IHNwYW4gNDsgfVxuXG5oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiAwLjg1cmVtO1xufVxuXG5oMixcbnAge1xuICBtYXJnaW46IDA7XG59XG5cbmgyIHtcbiAgY29sb3I6ICMxNzIwMzM7XG4gIGZvbnQtc2l6ZTogMC45MnJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbn1cblxucCxcbnNtYWxsIHtcbiAgY29sb3I6ICM2ZTc4OTA7XG59XG5cbmhlYWRlciBwIHtcbiAgZm9udC1zaXplOiAwLjcycmVtO1xuICBtYXJnaW4tdG9wOiAwLjE1cmVtO1xufVxuXG4uZnVubmVsIHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAwLjU1cmVtO1xufVxuXG4uZnVubmVsLXJvdyB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMC44cmVtO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDEwcmVtIG1pbm1heCgwLCAxZnIpIDNyZW07XG59XG5cbi5mdW5uZWwtbGFiZWwgc3Ryb25nIHtcbiAgY29sb3I6ICMxNzIwMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXNpemU6IDAuNzhyZW07XG59XG5cbi5mdW5uZWwtbGFiZWwgc21hbGwge1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAwLjY4cmVtO1xufVxuXG4uZnVubmVsLXRyYWNrIHtcbiAgYmFja2dyb3VuZDogI2VkZjJmYjtcbiAgYm9yZGVyLXJhZGl1czogMC4ycmVtO1xuICBoZWlnaHQ6IDEuMjVyZW07XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmZ1bm5lbC1maWxsIHtcbiAgYmFja2dyb3VuZDogdmFyKC0tcHJpbWFyeSk7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLmZ1bm5lbC10cmFjayBzcGFuIHtcbiAgY29sb3I6ICMxNzIwMzM7XG4gIGZvbnQtc2l6ZTogMC42OHJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgbGVmdDogMC40NXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMjVyZW07XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xufVxuXG4uYWdpbmcge1xuICBjb2xvcjogIzZlNzg5MDtcbiAgZm9udC1zaXplOiAwLjcycmVtO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmNvbXBhY3QtdGFibGUsXG4uY29tcGFjdC10YWJsZSB7XG4gIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY29tcGFjdC10YWJsZSB0aCxcbi5jb21wYWN0LXRhYmxlIHRkLFxuLmNvbXBhY3QtdGFibGUgdGgsXG4uY29tcGFjdC10YWJsZSB0ZCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkOWUxZWU7XG4gIGZvbnQtc2l6ZTogMC43MnJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzU7XG4gIHBhZGRpbmc6IDAuNDhyZW0gMC40MnJlbTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcbn1cblxuLmNvbXBhY3QtdGFibGUgdGgsXG4uY29tcGFjdC10YWJsZSB0aCB7XG4gIGJhY2tncm91bmQ6IHZhcigtLXRhYmxlLWJsdWUpO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgZm9udC1zaXplOiAwLjc4cmVtO1xuICBmb250LXdlaWdodDogODAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jb21wYWN0LXRhYmxlIHN0cm9uZyxcbi5jb21wYWN0LXRhYmxlIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTcyMDMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAwLjcycmVtO1xufVxuXG4uY29tcGFjdC10YWJsZSBzbWFsbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBmb250LXNpemU6IDAuNjhyZW07XG59XG5cbi5zdGF0dXMtcGlsbCxcbi5xdW90YS10b3Agc3BhbiB7XG4gIGJvcmRlci1yYWRpdXM6IDk5OXB4O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC42NHJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgcGFkZGluZzogMC4xOHJlbSAwLjQ1cmVtO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuXG4uaGlnaCxcbi5mdWxsIHtcbiAgYmFja2dyb3VuZDogI2ZmZTdlZjtcbiAgY29sb3I6ICNkMTFiNTQ7XG59XG5cbi5tZWRpdW0sXG4ubmVhci1mdWxsIHtcbiAgYmFja2dyb3VuZDogI2ZmZjJjZjtcbiAgY29sb3I6ICM4ZjVkMDA7XG59XG5cbi5sb3csXG4uaGVhbHRoeSB7XG4gIGJhY2tncm91bmQ6ICNkZWY5ZWY7XG4gIGNvbG9yOiAjMDA3NDUyO1xufVxuXG4ubG93LWRlbWFuZCB7XG4gIGJhY2tncm91bmQ6ICNlOGYyZmY7XG4gIGNvbG9yOiAjMTM2YWI1O1xufVxuXG4ucXVvdGEtbGlzdCxcbi5tb25leS1zdGFjayxcbi5zb3VyY2UtbGlzdCxcbi5yZWFkaW5lc3MtbGlzdCxcbi5xdWFsaXR5LWxpc3QsXG4ucXVldWUtbGlzdCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMC43cmVtO1xufVxuXG4ucXVvdGEtaXRlbSB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdhcDogMC4zOHJlbTtcbn1cblxuLnF1b3RhLXRvcCB7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cblxuLnF1b3RhLXRvcCBzdHJvbmcge1xuICBjb2xvcjogIzE3MjAzMztcbiAgZm9udC1zaXplOiAwLjc2cmVtO1xufVxuXG4ucXVvdGEtaXRlbSBzbWFsbCB7XG4gIGZvbnQtc2l6ZTogMC42OHJlbTtcbn1cblxuLm1vbmV5LXN0YWNrIHtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMywgMWZyKTtcbn1cblxuLm1vbmV5LXN0YWNrIGRpdiB7XG4gIGJhY2tncm91bmQ6ICNmOGZiZmY7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlMGU5ZjY7XG4gIGJvcmRlci1yYWRpdXM6IDAuM3JlbTtcbiAgcGFkZGluZzogMC43NXJlbTtcbn1cblxuLm1vbmV5LXN0YWNrIHNwYW4ge1xuICBjb2xvcjogIzZlNzg5MDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC42OHJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbn1cblxuLm1vbmV5LXN0YWNrIHN0cm9uZyB7XG4gIGNvbG9yOiAjMTcyMDMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAxcmVtO1xuICBtYXJnaW4tdG9wOiAwLjI1cmVtO1xufVxuXG4ucGF5bWVudC1zcGxpdCB7XG4gIGJvcmRlci1yYWRpdXM6IDAuMnJlbTtcbiAgZGlzcGxheTogZmxleDtcbiAgaGVpZ2h0OiAxLjhyZW07XG4gIG1hcmdpbjogMC44NXJlbSAwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4ucGF5bWVudC1zcGxpdCBzcGFuIHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZvbnQtc2l6ZTogMC42OHJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5wYXltZW50LXNwbGl0IHNwYW46bnRoLWNoaWxkKDEpIHsgYmFja2dyb3VuZDogIzAwZDY4ZjsgfVxuLnBheW1lbnQtc3BsaXQgc3BhbjpudGgtY2hpbGQoMikgeyBiYWNrZ3JvdW5kOiAjZmZhYTAwOyB9XG4ucGF5bWVudC1zcGxpdCBzcGFuOm50aC1jaGlsZCgzKSB7IGJhY2tncm91bmQ6ICNmZjNkNzE7IH1cblxuLnF1ZXVlLWxpc3QgPiBkaXYge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VkZjJmYjtcbiAgZ2FwOiAwLjdyZW07XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZy1ib3R0b206IDAuNXJlbTtcbn1cblxuLnF1ZXVlLWxpc3QgPiBkaXY6bGFzdC1jaGlsZCB7XG4gIGJvcmRlci1ib3R0b206IDA7XG4gIHBhZGRpbmctYm90dG9tOiAwO1xufVxuXG4ucXVldWUtbGlzdCBzdHJvbmcge1xuICBjb2xvcjogIzE3MjAzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC43MnJlbTtcbn1cblxuLnF1ZXVlLWxpc3Qgc21hbGwge1xuICBkaXNwbGF5OiBibG9jaztcbiAgZm9udC1zaXplOiAwLjY4cmVtO1xuICBtYXJnaW4tdG9wOiAwLjFyZW07XG59XG5cbi5xdWV1ZS1saXN0IGIge1xuICBmb250LXNpemU6IDAuN3JlbTtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cblxuLm92ZXJkdWUge1xuICBjb2xvcjogI2QxMWI1NDtcbn1cblxuLmR1ZS1zb29uLFxuLnBhcnRpYWwge1xuICBjb2xvcjogIzhmNWQwMDtcbn1cblxuLnZlcmlmeSB7XG4gIGNvbG9yOiAjMDA3NDUyO1xufVxuXG4ucmVhZGluZXNzLWl0ZW0sXG4ucXVhbGl0eS1saXN0ID4gZGl2IHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ2FwOiAwLjM1cmVtO1xufVxuXG4ucmVhZGluZXNzLWl0ZW0ge1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAyLjVyZW07XG59XG5cbi5yZWFkaW5lc3MtaXRlbSBuYi1wcm9ncmVzcy1iYXIsXG4ucXVhbGl0eS1saXN0IG5iLXByb2dyZXNzLWJhciB7XG4gIGdyaWQtY29sdW1uOiAxIC8gLTE7XG59XG5cbi5yZWFkaW5lc3MtaXRlbSBzdHJvbmcsXG4ucXVhbGl0eS1saXN0IHNwYW4ge1xuICBjb2xvcjogIzE3MjAzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC43NnJlbTtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbn1cblxuLnJlYWRpbmVzcy1pdGVtIHNtYWxsIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGZvbnQtc2l6ZTogMC42OHJlbTtcbn1cblxuLnJlYWRpbmVzcy1pdGVtID4gc3Bhbixcbi5xdWFsaXR5LWxpc3Qgc3Ryb25nIHtcbiAgY29sb3I6IHZhcigtLXByaW1hcnkpO1xuICBmb250LXNpemU6IDAuNzhyZW07XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4ucXVhbGl0eS1saXN0ID4gZGl2IHtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMi41cmVtO1xufVxuXG4uc291cmNlLWxpc3QgPiBkaXYge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBkaXNwbGF5OiBncmlkO1xuICBnYXA6IDAuNjVyZW07XG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogbWlubWF4KDdyZW0sIDEwcmVtKSAxZnIgMnJlbTtcbn1cblxuLnNvdXJjZS1saXN0IHNwYW4ge1xuICBjb2xvcjogIzJlM2E1OTtcbiAgZm9udC1zaXplOiAwLjcycmVtO1xufVxuXG4uc291cmNlLWxpc3QgZGl2IGRpdiB7XG4gIGJhY2tncm91bmQ6ICNlZGYyZmI7XG4gIGJvcmRlci1yYWRpdXM6IDAuMnJlbTtcbiAgaGVpZ2h0OiAwLjU1cmVtO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uc291cmNlLWxpc3QgaSB7XG4gIGJhY2tncm91bmQ6IHZhcigtLXByaW1hcnkpO1xuICBkaXNwbGF5OiBibG9jaztcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uc291cmNlLWxpc3Qgc3Ryb25nIHtcbiAgY29sb3I6ICMxNzIwMzM7XG4gIGZvbnQtc2l6ZTogMC43MnJlbTtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiAxMTgwcHgpIHtcbiAgLmFwcC1zaGVsbCB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiA0LjVyZW0gbWlubWF4KDAsIDFmcik7XG4gIH1cblxuICAuc2lkZS1uYXYgYSBzcGFuLFxuICAubmF2LWdyb3VwLFxuICAucG93ZXJlZCB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuXG4gIC5zaWRlLW5hdiBhIHtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBwYWRkaW5nOiAwO1xuICB9XG5cbiAgLmZpbHRlci1yb3csXG4gIC5tZXRyaWMtc3RyaXAge1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDIsIG1pbm1heCgwLCAxZnIpKTtcbiAgfVxuXG4gIC5zcGFuLTcsXG4gIC5zcGFuLTUsXG4gIC5zcGFuLTQge1xuICAgIGdyaWQtY29sdW1uOiBzcGFuIDEyO1xuICB9XG59XG5cbkBtZWRpYSAobWF4LXdpZHRoOiA3NjBweCkge1xuICAudG9wLXJpZ2h0IHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLmFwcC1zaGVsbCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gIH1cblxuICAuc2lkZS1uYXYge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAuY29udGVudCB7XG4gICAgcGFkZGluZzogMXJlbTtcbiAgfVxuXG4gIC5wYWdlLWJhcixcbiAgLmRhc2hib2FyZC1oZWFkaW5nIHtcbiAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICB9XG5cbiAgLmZpbHRlci1yb3csXG4gIC5tZXRyaWMtc3RyaXAsXG4gIC5tb25leS1zdGFjayB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnI7XG4gIH1cblxuICAuZnVubmVsLXJvdyB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnI7XG4gIH1cblxuICAuYWdpbmcge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbn1cbiJdfQ== */"] });


/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ 1570);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ 718);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 1707);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 1258);
/* harmony import */ var _nebular_theme__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @nebular/theme */ 465);
/* harmony import */ var _nebular_eva_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @nebular/eva-icons */ 8560);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2316);










class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule,
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__.BrowserAnimationsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forRoot([], { relativeLinkResolution: 'legacy' }),
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbThemeModule.forRoot({ name: 'default' }),
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbSidebarModule.forRoot(),
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbDatepickerModule.forRoot(),
            _nebular_eva_icons__WEBPACK_IMPORTED_MODULE_7__.NbEvaIconsModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbLayoutModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbCardModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbSelectModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbButtonModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbIconModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbBadgeModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbProgressBarModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbTabsetModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbInputModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbFormFieldModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbUserModule,
            _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbAlertModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule,
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__.BrowserAnimationsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule, _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbThemeModule, _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbSidebarModule, _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbDatepickerModule, _nebular_eva_icons__WEBPACK_IMPORTED_MODULE_7__.NbEvaIconsModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbLayoutModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbCardModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbSelectModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbButtonModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbIconModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbBadgeModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbProgressBarModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbTabsetModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbInputModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbFormFieldModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbUserModule,
        _nebular_theme__WEBPACK_IMPORTED_MODULE_6__.NbAlertModule] }); })();


/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
const environment = {
    production: false
};


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 1570);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2316);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.error(err));


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map